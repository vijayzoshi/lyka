package com.example.lyka;

public class diseaseadapter {
}
