package com.example.lyka;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ExpertsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_experts);
    }
}